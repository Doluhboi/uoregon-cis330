#include <PNMwriterCPP.h>
#include <iostream>
#include <fstream>

using namespace std;

/* writes the image data to a .pnm file using fstream */
void PNMwriterCPP::Write(char *filename) {
	int w = img1->getWidth();
	int h = img1->getHeight();
	ofstream ofs;

	ofs.open(filename, ios::binary);

	ofs << "P6" << endl;
	ofs << w << " " << h << endl;
	ofs << 255 << endl;

	ofs.write((char *) img1->getData(), w*h*3);

	ofs.close();
}


