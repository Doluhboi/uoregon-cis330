#include <math330.h>
#include <math.h>

double arctan330(double angle)
{
	return atan(angle);
}

