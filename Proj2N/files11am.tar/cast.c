int main()
{
    int HRC = 79;
    char HRC2 = (char) HRC;
    float HRC3 = 7.5;
    int   HRC4 = (int) HRC3;
}
