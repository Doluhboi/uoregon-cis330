#include <stdlib.h>
#include <stdio.h>

void
print_list(int *list, int nList)
{
    int i;
    for (i = 0 ; i < nList ; i++)
    {
        printf("%d", list[i]);
        if (i % 10 == 9)
            printf("\n");
        else
            printf("\t");
    }
}

int 
int_compare(const void *v1, const void *v2)
{
    int *i1 = (int *) v1;
    int *i2 = (int *) v2;

    if (*i1 < *i2)
       return -1;
    else if (*i1 > *i2)
       return +1;
    else
       return 0;
}

int main()
{
    int list[100];
    int i, j;
    for (i = 0 ; i < 100 ; i++)
    {
        list[i] = rand()%1000;
    }

    printf("Before:\n");
    print_list(list, 100);

    /* qsort(list, 100, sizeof(int), int_compare); */

    for (i = 0 ; i < 99 ; i++)
    {
        for (j = i+1 ; j < 100 ; j++)
        {
            if (list[i] > list[j])
            {
                int tmp = list[j];
                list[j] = list[i];
                list[i] = tmp;
            }
        }
    }

    printf("After:\n");
    print_list(list, 100);
}
