#include <stdlib.h>
#include <stdio.h>

typedef struct
{
    int cents;
    int dollars;
} money;

void
print_money_list(money *list, int nList)
{
    int i;
    for (i = 0 ; i < nList ; i++)
    {
        printf("$%d.%02d", list[i].dollars, list[i].cents);
        if (i % 8 == 7)
            printf("\n");
        else
            printf("\t");
    }
}

void
print_int_list(int *list, int nList)
{
    int i;
    for (i = 0 ; i < nList ; i++)
    {
        printf("%d", list[i]);
        if (i % 10 == 9)
            printf("\n");
        else
            printf("\t");
    }
}

int 
money_compare(const void *v1, const void *v2)
{
    money *i1 = (money *) v1;
    money *i2 = (money *) v2;

    if (i1->dollars < i2->dollars)
       return -1;
    else if (i1->dollars > i2->dollars)
       return +1;
    if (i1->cents < i2->cents)
       return -1;
    else if (i1->cents > i2->cents)
       return +1;
    else
       return 0;
}

int 
int_compare(const void *v1, const void *v2)
{
    int *i1 = (int *) v1;
    int *i2 = (int *) v2;

    if (*i1 < *i2)
       return -1;
    else if (*i1 > *i2)
       return +1;
    else
       return 0;
}

int main()
{
    money list[100];
    int i;
    for (i = 0 ; i < 100 ; i++)
    {
        list[i].dollars = rand()%1000;
        list[i].cents = rand()%100;
    }

    printf("Before:\n");
    print_money_list(list, 100);

    qsort(list, 100, sizeof(money), money_compare);

    printf("\nAfter:\n");
    print_money_list(list, 100);
}
