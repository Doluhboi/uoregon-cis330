#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct
{
    int cents;
    int dollars;
} money;


void
bsort(void *base, size_t nList, size_t width,
         int (*compar)(const void *, const void *))
{
    int indexOfSmallestElementInArray = 0;
    int i;
    void *locationToCopyTo = NULL;
    void *locationToCopyFrom = NULL;
    void *tmp = NULL;

    if (nList == 1)
       return;

    for (i = 1 ; i < nList ; i++)
    {
        void *locationOfCurrentSmallest = base+width*indexOfSmallestElementInArray;
        void *locationOfCandidate = base+width*i;
        if (compar(locationOfCurrentSmallest, locationOfCandidate) > 0)
        {
            indexOfSmallestElementInArray = i;
        }
    }

    tmp = malloc(width);
    locationToCopyTo = base;
    locationToCopyFrom = base+width*indexOfSmallestElementInArray;
/*
  A <--> B
  T
  T = A
  A = B
  B = T
 */

    /* swap 0 and indexOfSmallestElementInArray */
    memcpy(tmp, locationToCopyTo, width);
    memcpy(locationToCopyTo, locationToCopyFrom, width);
    memcpy(locationToCopyFrom, tmp, width);
    free(tmp);


    /* repeat for remainder of list */
    bsort(base+width, nList-1, width, compar); 
}

void
print_money_list(money *list, int nList)
{
    int i;
    for (i = 0 ; i < nList ; i++)
    {
        printf("$%d.%02d", list[i].dollars, list[i].cents);
        if (i % 8 == 7)
            printf("\n");
        else
            printf("\t");
    }
}

void
print_int_list(int *list, int nList)
{
    int i;
    for (i = 0 ; i < nList ; i++)
    {
        printf("%d", list[i]);
        if (i % 10 == 9)
            printf("\n");
        else
            printf("\t");
    }
}

int 
money_compare(const void *v1, const void *v2)
{
    money *i1 = (money *) v1;
    money *i2 = (money *) v2;

    /*printf("Money compare got $%d.%02d and $%d.%02d\n", i1->dollars, i1->cents, i2->dollars, i2->cents); */
    if (i1->dollars < i2->dollars)
       return -1;
    else if (i1->dollars > i2->dollars)
       return +1;
    if (i1->cents < i2->cents)
       return -1;
    else if (i1->cents > i2->cents)
       return +1;
    else
       return 0;
}

int 
int_compare(const void *v1, const void *v2)
{
    int *i1 = (int *) v1;
    int *i2 = (int *) v2;

    if (*i1 < *i2)
       return -1;
    else if (*i1 > *i2)
       return +1;
    else
       return 0;
}

int main()
{
    money list[100];
    int i;
    for (i = 0 ; i < 100 ; i++)
    {
        list[i].dollars = rand()%1000;
        list[i].cents = rand()%100;
    }

    printf("Before:\n");
    print_money_list(list, 100);

    bsort(list, 100, sizeof(money), money_compare);

    printf("\nAfter:\n");
    print_money_list(list, 100);
    printf("\n");
}
